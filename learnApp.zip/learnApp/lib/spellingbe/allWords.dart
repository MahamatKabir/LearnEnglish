const List<String> allWords= ['cat','horse','dog','lion'];

const List<String> numberWords= ['five','tree','six','eight','seven','one','four',];
const List<String> colorWords= ['black','green','pink','brown','white','orange','blue',];