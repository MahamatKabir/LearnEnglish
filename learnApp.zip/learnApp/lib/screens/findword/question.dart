

class Question {
  String flagName;
  String answer1;
  String answer2;
  String answer3;
  String correctAnswer;

  Question({ required this.flagName, required this.answer1, required this.answer2, required this.answer3,required this.correctAnswer});
}