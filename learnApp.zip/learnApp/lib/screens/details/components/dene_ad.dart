import 'package:flutter/material.dart';


class Denead extends StatelessWidget {
  const Denead({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar:AppBar(
        title: Text("nijeria") ,
      )
    );
  }
}